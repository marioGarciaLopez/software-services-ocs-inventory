# User Installed Apps
Get applications installed by user