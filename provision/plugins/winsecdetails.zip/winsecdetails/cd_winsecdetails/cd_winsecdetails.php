<?php
###############################################################################
## OCSINVENTORY-NG
## Copyleft Bálint FÜZI 2022
## Web : http://www.ocsinventory-ng.org
##
## This code is open source and may be copied and modified as long as the source
## code is always made freely available.
## Please refer to the General Public Licence http://www.gnu.org/ or Licence.txt
################################################################################

if (AJAX) {
    parse_str($protectedPost['ocs']['0'], $params);
    $protectedPost += $params;
    ob_start();
    $ajax = true;
} else {
    $ajax = false;
}

print_item_header($l->g(57420));

if (!isset($protectedPost['SHOW'])) {
    $protectedPost['SHOW'] = 'NOSHOW';
}

$form_name = "winsecdetails";

$table_name = $form_name;
$tab_options = $protectedPost;
$tab_options['form_name'] = $form_name;
$tab_options['table_name'] = $table_name;

echo open_form($form_name);

$list_fields = array(
    'Behavior Monitor Enabled'              => 'BEHAVIORMONITORENABLED',
    'Ioav Protection Enabled'               => 'IOAVPROTECTIONENABLED',
    'Is Tamper Protected'                   => 'ISTAMPERPROTECTED',
    'On Access Protection Enabled'          => 'ONACCESSPROTECTIONENABLED',
    'Real Time Protection Enabled'          => 'REALTIMEPROTECTIONENABLED',
    'Tamper Protection Source'              => 'TAMPERPROTECTIONSOURCE'
);

$list_col_cant_del = $list_fields;
$default_fields = $list_fields;

$list_fields['AM Engine Version']                   = 'AMENGINEVERSION';
$list_fields['AM Product Version']                  = 'AMPRODUCTVERSION';
$list_fields['AM Running Mode']                     = 'AMRUNNINGMODE';
$list_fields['AM Service Enabled']                  = 'AMSERVICEENABLED';
$list_fields['AM Service Version']                  = 'AMSERVICEVERSION';
$list_fields['Anti-spyware Enabled']                = 'ANTISPYWAREENABLED';
$list_fields['Anti-spyware Signature Age']          = 'ANTISPYWARESIGNATUREAGE';
$list_fields['Anti-spyware Signature Last Updated'] = 'ANTISPYWARESIGNATURELASTUPDATED';
$list_fields['Anti-spyware Signature Version']      = 'ANTISPYWARESIGNATUREVERSION';
$list_fields['Antivirus Enabled']                   = 'ANTIVIRUSENABLED';
$list_fields['Antivirus Signature Age']             = 'ANTIVIRUSSIGNATUREAGE';
$list_fields['Antivirus Signature Last Updated']    = 'ANTIVIRUSSIGNATURELASTUPDATED';
$list_fields['Antivirus Signature Version']         = 'ANTIVIRUSSIGNATUREVERSION';
$list_fields['NIS Enabled']                         = 'NISENABLED';
$list_fields['NIS Engine Version']                  = 'NISENGINEVERSION';
$list_fields['NIS Signature Age']                   = 'NISSIGNATUREAGE';
$list_fields['NIS Signature Last Updated']          = 'NISSIGNATURELASTUPDATED';
$list_fields['NIS Signature Version']               = 'NISSIGNATUREVERSION';

$sql = prepare_sql_tab($list_fields);
$sql['SQL']  .= "FROM winsecdetails WHERE (hardware_id = $systemid)";

array_push($sql['ARG'], $systemid);

$tab_options['ARG_SQL'] = $sql['ARG'];
$tab_options['ARG_SQL_COUNT'] = $systemid;

ajaxtab_entete_fixe($list_fields, $default_fields, $tab_options, $list_col_cant_del);

echo close_form();

if ($ajax) {
    ob_end_clean();
    tab_req($list_fields, $default_fields, $list_col_cant_del, $sql['SQL'], $tab_options);
    ob_start();
}
?>