# Windows Security Details 

**List of Data Collected**

Data is collected from `Get-MPComputerStatus` ps command

* AMEngineVersion
* AMProductVersion
* AMRunningMode
* AMServiceEnabled
* AMServiceVersion
* AntispywareEnabled
* AntispywareSignatureAge
* AntispywareSignatureLastUpdated
* AntispywareSignatureVersion
* AntivirusEnabled
* AntivirusSignatureAge
* AntivirusSignatureLastUpdated
* AntivirusSignatureVersion
* BehaviorMonitorEnabled
* IoavProtectionEnabled
* IsTamperProtected
* NISEnabled
* NISEngineVersion
* NISSignatureAge
* NISSignatureLastUpdated
* NISSignatureVersion
* OnAccessProtectionEnabled
* RealTimeProtectionEnabled
* TamperProtectionSource



