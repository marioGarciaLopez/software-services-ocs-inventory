# Compare devices 
Please make sure you run 'composer install' inside the comparedevices directory otherwise it will display a blank page

Compare devices informations and get differences

