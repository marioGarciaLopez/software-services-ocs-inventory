#!/usr/bin/php
<?php
require_once("class/greenitCron.class.php");

$cronStats = new CronStats;
$cronStats->Options();